// $(function(){
//   $('#reviewForm').validate({
//     rules:{
//       name:{
//         required: true,
//       },
//       message:{
//         required: true,
//       }
//     },
//     messages: {
//       name: {
//         required: "Please enter your name"
//       },
//       message: {
//         required: "Please enter your review here"
//       }
//     }
//   })(jQuery)
// })




const firebaseConfig = {
    apiKey: "AIzaSyDVlJMLsp2PjZBL5x84i9uj0FJodc2-470",
    authDomain: "gameon-e6d58.firebaseapp.com",
    databaseURL: "https://gameon-e6d58-default-rtdb.firebaseio.com",
    projectId: "gameon-e6d58",
    storageBucket: "gameon-e6d58.appspot.com",
    messagingSenderId: "965247037298",
    appId: "1:965247037298:web:fcda9ff14214bc1363f7eb"
  };

  firebase.initializeApp(firebaseConfig);
  
  document.addEventListener("DOMContentLoaded", function () {
  //reference your database
  var reviewFormDB = firebase.database().ref("reviewForm");

  document.getElementById("reviewForm").addEventListener("submit", submitForm);

  function submitForm(e) {
    e.preventDefault();

    var name = getElementVal("name");
    var message = getElementVal("message");

    saveMessages(name, message);

    //   enable alert
  document.querySelector(".alert").style.display = "block";

  //   remove the alert
  setTimeout(() => {
    document.querySelector(".alert").style.display = "none";
  }, 3000);

  //   reset the form
  document.getElementById("reviewForm").reset();
}
  //save reviews to the database
  const saveMessages = (name, message) =>{
    var newReviewForm = reviewFormDB.push();

    newReviewForm.set({
        name: name,
        message: message,
    });
  };

  const getElementVal = (id) => {
    return document.getElementById(id).value;
  };

document.addEventListener("DOMContentLoaded", function () {

  //Retrive Info
  function retrieveInfos(){
    let ref = firebase.database().ref("reviewForm");
    ref.on("value", gotData);
  }

  function gotData(data) {
    let info = data.value();
    let keys = Object.keys(info);

    let infosResults = document.querySelector("infosResults");
    infosResults.innerHTML = '';

    for (let i = 0; i < keys.length; i++) {
      let infoData = keys[i];
      let name = info[infoData].name;
      let message = info[infoData].message;
      console.log(name, message);

      let entryDiv = document.createElement("div");
      entryDiv.innerHTML += `
      <p><strong>Name: </strong>${name} <br/>
      <a><strong>Review: </strong>${message}</a><br/>
      </p>`;

      infosResults.appendChild(entryDiv);
    }
  }

  retrieveInfos();

});

});